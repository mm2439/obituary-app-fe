


const ButtonGrad =()=>{
    return(
        <div style={{
                display: 'inline-block',
                padding: '10px 20px',
                fontSize: '16px',
                fontWeight: 'bold',
                color: 'black',
                textAlign: 'center',
                border: '15px',
                background: [linear-gradient('50% 50% at 50% 50%, rgba(255, 255, 255, 0) 0%', 'rgba(10, 133, 194, 0.03) 100%'),
                            linear-gradient('259.47deg, rgba(61, 163, 77, 0.08) 4.77%', 'rgba(255, 172, 0, 0.08) 27.71%'),
                            linear-gradient('260.89deg, rgba(172, 255, 185, 0.13) 77.79%', 'rgba(0, 209, 196, 0.13) 99.16%'),
                            linear-gradient('0deg, rgba(255, 255, 255, 0.4)', 'rgba(255, 255, 255, 0.4)')],
                border:' 2px solid',
                // border-image-source: linear-gradient('180deg, #BE97FF 0%, #530CC6 100%'),
                // border-image-slice: 1;
              
              
              
              
        }}>

        </div>
    )
}