"use client";
import React from "react";
import UserAccountLayout from "../useraccountlayout/UserAccountLayout";
import AddContact from "../components/appcomponents/AddContact";
const DodajVsebine = () => {
  return (
    <UserAccountLayout>
      <AddContact />
    </UserAccountLayout>
  );
};

export default DodajVsebine;
