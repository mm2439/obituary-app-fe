"use client";
import React from "react";
import UserAccountLayout from "../useraccountlayout/UserAccountLayout";
import Mycontributions from "../components/appcomponents/Mycontributions";
const MojiPrispevki = () => {
  return (
    <UserAccountLayout>
      <Mycontributions />
    </UserAccountLayout>
  );
};

export default MojiPrispevki;
