"use client";
import React from "react";
import UserAccountLayout from "../useraccountlayout/UserAccountLayout";
import PostConfirmation from "../components/appcomponents/PostConfirmation";
const PotrditevObjave = () => {
  return (
    <UserAccountLayout>
      <PostConfirmation />
    </UserAccountLayout>
  );
};

export default PotrditevObjave;
