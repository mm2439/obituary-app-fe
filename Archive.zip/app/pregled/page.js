"use client";
import React from "react";
import UserAccountLayout from "../useraccountlayout/UserAccountLayout";
import ReviewUserAccount from "../components/appcomponents/ReviewUserAccount";
const Pregled = () => {
  return (
    <UserAccountLayout>
      <ReviewUserAccount />
    </UserAccountLayout>
  );
};

export default Pregled;
