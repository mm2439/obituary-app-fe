"use client";
import React from "react";
import UserAccountLayout from "../useraccountlayout/UserAccountLayout";
import Guardians from "../components/appcomponents/Guardians";
const Pregled2 = () => {
  return (
    <UserAccountLayout>
      <Guardians />
    </UserAccountLayout>
  );
};

export default Pregled2;
