"use client"

import React from 'react'
import HomePageBox from '../components/appcomponents/HomePageBox'
import SlideTwo from '../components/slidercomponents/SlideTwo'
import IphoneView from '../components/appcomponents/IphoneView'
const ViewCards = () => {
  return (
      <SlideTwo/>

  )
}

export default ViewCards